<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="cyber_space_tileset1" tilewidth="32" tileheight="32" tilecount="4" columns="2">
 <image source="tileset1.png" trans="000000" width="64" height="64"/>
</tileset>
